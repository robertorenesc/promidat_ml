from enum import Enum

class LinkageMethod(Enum):

    SINGLE = "single"
    AVERAGE = "average"
    COMPLETE = "complete"
    WARD = "ward"

